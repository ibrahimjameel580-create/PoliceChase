# Police Chase Android

This is an Android Studio project wrapping the Police Chase V12 HTML game in a full-screen WebView.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose Build > Build APK(s).
4. Install the generated APK on an Android phone.

The game itself is included at:
app/src/main/assets/police_chase.html

No internet permission is required for the game.
